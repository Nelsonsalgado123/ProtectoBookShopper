// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import "controllers"
import "./jquery.min.js"
import "./bootstrap.bundle.min.js"
import "./sb-admi-2.min.js"
;
